"""
itypes module. by Al Korgun (AlKorgun@gmail.com)

This is dynamic classes module, whith allows to change
class objects dynamicly and return changed values.
"""

__all__ = ["Number"]

__version__ = "0.3"

class Number(int):
	"""Class of dynamic numbers"""
	def __init__(self, numb = int()):
		int.__init__(self, numb)
		self.iter = numb
	"""Number enlarges and returns"""
	def plus(self, numb = 0x1):
		self.__init__(self.iter + numb)
		return int(self.iter)
	"""Number reduces and returns"""
	def minus(self, numb = 0x1):
		self.__init__(self.iter - numb)
		return int(self.iter)
	"""Returns `str` number"""
	def _str(self):
		return str(self.iter)
	"""Returns `float` number"""
	def _float(self):
		return float(self.iter)
	"""Returns integear"""
	def _int(self):
		return int(self.iter)
