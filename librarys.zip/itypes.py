"""
itypes module. by Al Korgun (AlKorgun@gmail.com)

Module contains Classes with Superstructure.
It's just for convenience.
"""

import sqlite3

__all__ = [
	"Number",
	"Base"
			]

__version__ = "0.4"

class Number(int):

	def __init__(self, numb = int()):
		int.__init__(self, numb)
		self.iter = numb

	def plus(self, numb = 0x1):
		self.__init__(self.iter + numb)
		return int(self.iter)

	def minus(self, numb = 0x1):
		self.__init__(self.iter - numb)
		return int(self.iter)

	def _str(self):
		return str(self.iter)

	def _float(self):
		return float(self.iter)

	def _int(self):
		return int(self.iter)

class Base:

	def __init__(self, filename, edt = 8):
		self.db = sqlite3.connect(filename, edt)
		self.cursor = self.db.cursor()
		self.commit = self.db.commit
		self.execute = self.cursor.execute
		self.fetchone = self.cursor.fetchone
		self.fetchall = self.cursor.fetchall
		self.fetchmany = self.cursor.fetchmany

	def close(self):
		if self.cursor:
			self.cursor.close()
		if self.db.total_changes:
			self.commit()
		if self.db:
			self.db.close()

	def __enter__(self):
		return self

	def __exit__(self, *ls):
		self.close()
