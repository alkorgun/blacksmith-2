"""
itypes module. by Al Korgun (AlKorgun@gmail.com)

This is dynamic class types module, whith allows to change
class objects dynamicly and returns changed values.
"""

__all__ = ["Number"]

__version__ = "0.2"

class Number:
	"""Class of dynamic numbers"""
	def __init__(self, numb = 0):
		self.numb = numb
	"""Number enlarges and returns"""
	def plus(self, number = 1):
		self.numb += number
		return self.numb
	"""Number reduces and returns"""
	def minus(self, number = 1):
		self.numb -= number
		return self.numb
	"""Returns `str` number"""
	def _str(self):
		return str(self.numb)
	"""Returns `float` number"""
	def _float(self):
		return float(self.numb)
	"""Returns integear"""
	def _int(self):
		return int(self.numb)
	"""Returns rounded number"""
	def _round(self, number = 1):
		return round(self.numb, number)
