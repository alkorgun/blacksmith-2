"""
BlackSmith bot's module "enconf"
enconf.py

Copyright (2009-2014) Al Korgun (alkorgun@gmail.com)

Distributed under the GNU GPLv3.
"""

from os.path import supports_unicode_filenames, sep as os_dsep

AsciiSys = (not supports_unicode_filenames)

del supports_unicode_filenames

from base64 import b16encode as encode_name

__all__ = [
	"AsciiSys",
	"CharCase",
	"AsciiTab",
	"encode_name",
	"cefile",
	"check_nosymbols",
	"encode_filename"
]

__version__ = "3.0"

CharCase = [
	"ABCDEFGHIJKLMNOPQRSTUVWXYZ",
	"abcdefghijklmnopqrstuvwxyz",
	"0123456789",
	'''!"#$%&'()*+,-./:;<=>?@[\]^_`{|}~'''
]

AsciiTab = tuple(str.join("", CharCase))

def cefile(path):
	path = path.replace("\t", "\\t")
	path = path.replace("\n", "\\n")
	path = path.replace("\r", "\\r")
	if (path.count(chr(47)) > 1):
		if not check_nosymbols(path):
			path = encode_filename(path)
	return path

def cefile_new(path):
	path = path.replace("\t", "\\t")
	path = path.replace("\n", "\\n")
	path = path.replace("\r", "\\r")
	return path.encode("utf-8")

def check_nosymbols(iterable, check = AsciiSys, allowedChars = AsciiTab):
	if check:
		for char in iterable:
			if char not in allowedChars:
				return False
	return True

def check_nosymbols_new(iterable):
	for char in iterable:
		if char not in AsciiTab:
			return False
	return True

def encode_filename(dpath, sep = chr(64)):
	encodedName = []
	for part in dpath.split(chr(47)):
		if sep in part:
			chatName, other = part.split(sep, 1)
			encodedName.append(sep.join((encode_name(chatName.encode("utf-8")), other)))
		else:
			encodedName.append(part)
	return os_dsep.join(encodedName)

def encode_filename_old(dpath, sep = chr(64)):
	encodedName = []
	for part in dpath.split(chr(47)):
		if sep in name:
			chatName, other = part.split(sep, 1)
			chatName = encode_name(chatName.encode("utf-8"))
			encodedName.append("%s@%s" % (chatName[(len(chatName) / 2):], other))
		else:
			encodedName.append(part)
	return os_dsep.join(encodedName)
